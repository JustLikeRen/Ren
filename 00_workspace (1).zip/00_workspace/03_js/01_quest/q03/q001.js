var r = Math.floor(Math.random() * 6) + 1; // 1 ~ n 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.

if(r > 2)
{
    document.write("성공");
}
else
{
    document.write("실패");
};


// if(r < 2)
// {
// document.write("실패")
// };

// document.write("2코뿔소")
