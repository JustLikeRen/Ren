var i = 100;

if (i>1) {
    alert("크다");
}