var i = prompt("값을입력하세요");
// var i = "111"

if (i>100) {
    alert("100보다큽니다");
    
} else { 
    alert("100이하입니다");
}