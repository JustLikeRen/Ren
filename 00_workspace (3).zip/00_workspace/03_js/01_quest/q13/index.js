var i = prompt("값을입력하세요");

if (i>100) {
    alert("100보다큽니다");
    
} else { 
    if (i<100) {
        alert("100보다 작습니다")
    } else {
        alert("100입니다.")
    }
}