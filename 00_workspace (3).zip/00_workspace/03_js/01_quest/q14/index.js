var i = prompt("값을입력하세요");

switch (i) {
    case "1":
        alert("1")
        break;
    case "2":
        alert("2")
        break;
    case "3":
        alert("3")
        break;

    default:
        alert("1,2,3이 아닙니다.")
        break;
}