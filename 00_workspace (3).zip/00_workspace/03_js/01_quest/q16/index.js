
    var t = 1;

    
    
    while(t<=10){
    document.write(t)
    t=t+1;
    }