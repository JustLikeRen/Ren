for(var i=1; i<=10; i=i+1){
    for(var j=10; j>=i; j=j-1){
        document.write("☆")
    }
    document.write("<br>")
}