// var a = "4살";
// var t = "ragdoll";
// var n = "초이";
// var s = a + t + n;
// alert(s);

// alert ("4살"+"ragdoll"+"초이")

function x() {
    var a = "4살";
    var t = "ragdoll";
    var n = "초이";
    var s = a + t + n;
    alert(s);
}

x();