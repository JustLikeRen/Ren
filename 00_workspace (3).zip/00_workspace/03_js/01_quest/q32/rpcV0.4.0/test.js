function x (a,b) {

    var sum = a+b
    document.write("두수를 더한 결과는: "+a+b)
}

x(1,2);

x(5,8);