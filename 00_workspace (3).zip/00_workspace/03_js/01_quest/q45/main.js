function Cat() {
    this.name;
    this.age;
    this.weight
    this.family="ragdoll";
    this.color;
}

new Cat(); 

var kitty = new Cat(); //변수 선언

kitty.name = "시로"
kitty.age=3;
kitty.weight=4;

kitty.color="white"

document.write(kitty.name); br();
document.write(kitty.age); br();
document.write(kitty.weight); br();
document.write(kitty.family); br();
document.write(kitty.color); br();

br();br();

var yaongi = new Cat()

yaongi.name="쿠로"
yaongi.age=4;
yaongi.weight=5;

yaongi.color="black"

document.write(yaongi.name); br();
document.write(yaongi.age); br();
document.write(yaongi.weight); br();
document.write(yaongi.family); br();
document.write(yaongi.color); br();