

function check(){
    alert("테스트");
}