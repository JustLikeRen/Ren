var cat = 1;
var dog = 1+2;

alert(3);

var sum = cat+dog;

alert(sum);

alert(-dog+sum);