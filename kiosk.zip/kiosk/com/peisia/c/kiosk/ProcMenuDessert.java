package com.peisia.c.kiosk;

public class ProcMenuDessert {
	
	public void run() {
		zz:while(true) {
			//메뉴출력
			Kiosk.p4.info();
			Kiosk.p5.info();
			
			System.out.println("[1.케이크/2.쿠키/x.이전메뉴로]");
			System.out.println("");
			Kiosk.cmd = Kiosk.sc.next();
			switch(Kiosk.cmd) {
			case "1":
				System.out.println("케이크 선택됨");
				
//				Product x = new Product("아아",1000);
				Kiosk.basket.add(Kiosk.p4);
				
				break;
			case "2":
				System.out.println("쿠키 선택됨");
				Kiosk.basket.add(Kiosk.p5);
				break;
			case "x":
				System.out.println("이전 메뉴 이동");
				break zz;
			}
		}
	}
}
